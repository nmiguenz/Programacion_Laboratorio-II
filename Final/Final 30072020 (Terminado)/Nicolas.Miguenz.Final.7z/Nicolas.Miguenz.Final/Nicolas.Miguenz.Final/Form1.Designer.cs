﻿namespace Nicolas.Miguenz.Final
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTimer1 = new System.Windows.Forms.Label();
            this.btnIniciar1 = new System.Windows.Forms.Button();
            this.lblTimer2 = new System.Windows.Forms.Label();
            this.btnIniciar2 = new System.Windows.Forms.Button();
            this.lblTimer3 = new System.Windows.Forms.Label();
            this.btnIniciar3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTimer1
            // 
            this.lblTimer1.AutoSize = true;
            this.lblTimer1.Location = new System.Drawing.Point(84, 26);
            this.lblTimer1.Name = "lblTimer1";
            this.lblTimer1.Size = new System.Drawing.Size(71, 20);
            this.lblTimer1.TabIndex = 0;
            this.lblTimer1.Text = "00:00.00";
            // 
            // btnIniciar1
            // 
            this.btnIniciar1.Location = new System.Drawing.Point(12, 65);
            this.btnIniciar1.Name = "btnIniciar1";
            this.btnIniciar1.Size = new System.Drawing.Size(216, 103);
            this.btnIniciar1.TabIndex = 1;
            this.btnIniciar1.Text = "Contador 1";
            this.btnIniciar1.UseVisualStyleBackColor = true;
            this.btnIniciar1.Click += new System.EventHandler(this.btnIniciar1_Click);
            // 
            // lblTimer2
            // 
            this.lblTimer2.AutoSize = true;
            this.lblTimer2.Location = new System.Drawing.Point(84, 213);
            this.lblTimer2.Name = "lblTimer2";
            this.lblTimer2.Size = new System.Drawing.Size(71, 20);
            this.lblTimer2.TabIndex = 2;
            this.lblTimer2.Text = "00:00.00";
            // 
            // btnIniciar2
            // 
            this.btnIniciar2.Location = new System.Drawing.Point(12, 251);
            this.btnIniciar2.Name = "btnIniciar2";
            this.btnIniciar2.Size = new System.Drawing.Size(216, 103);
            this.btnIniciar2.TabIndex = 3;
            this.btnIniciar2.Text = "Contador 2";
            this.btnIniciar2.UseVisualStyleBackColor = true;
            this.btnIniciar2.Click += new System.EventHandler(this.btnIniciar2_Click);
            // 
            // lblTimer3
            // 
            this.lblTimer3.AutoSize = true;
            this.lblTimer3.Location = new System.Drawing.Point(84, 383);
            this.lblTimer3.Name = "lblTimer3";
            this.lblTimer3.Size = new System.Drawing.Size(71, 20);
            this.lblTimer3.TabIndex = 4;
            this.lblTimer3.Text = "00:00.00";
            // 
            // btnIniciar3
            // 
            this.btnIniciar3.Location = new System.Drawing.Point(12, 419);
            this.btnIniciar3.Name = "btnIniciar3";
            this.btnIniciar3.Size = new System.Drawing.Size(216, 103);
            this.btnIniciar3.TabIndex = 5;
            this.btnIniciar3.Text = "Contador 3";
            this.btnIniciar3.UseVisualStyleBackColor = true;
            this.btnIniciar3.Click += new System.EventHandler(this.btnIniciar3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(243, 555);
            this.Controls.Add(this.btnIniciar3);
            this.Controls.Add(this.lblTimer3);
            this.Controls.Add(this.btnIniciar2);
            this.Controls.Add(this.lblTimer2);
            this.Controls.Add(this.btnIniciar1);
            this.Controls.Add(this.lblTimer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTimer1;
        private System.Windows.Forms.Button btnIniciar1;
        private System.Windows.Forms.Label lblTimer2;
        private System.Windows.Forms.Button btnIniciar2;
        private System.Windows.Forms.Label lblTimer3;
        private System.Windows.Forms.Button btnIniciar3;
    }
}

