﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades;

namespace Nicolas.Miguenz.Final
{
    public partial class Form1 : Form, IEvento
    {
        private IReloj ireloj;
        public Form1()
        {
            InitializeComponent();
            ireloj = new Relojes(2, this);

        }

        public void ImprimirReloj(Relojes.Reloj reloj, string dato)
        {
            if (this.InvokeRequired)
            {
                Contador.EventoReloj ev = new Contador.EventoReloj(ImprimirReloj);
                object[] obj = new object[] { reloj, dato };
                this.Invoke(ev, obj);
            }
            else
            {
                switch (reloj)
                {
                    case Relojes.Reloj.Primero:
                        lblTimer1.Text = dato;
                        break;
                    case Relojes.Reloj.Segundo:
                        lblTimer2.Text = dato;
                        break;
                    case Relojes.Reloj.Tercero:
                        lblTimer3.Text = dato;
                        break;
                }
            }
        }

        public void StarStopReloj(Relojes.Reloj reloj)
        {
            try
            {
                ireloj.CargarReloj(reloj);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void btnIniciar1_Click(object sender, EventArgs e)
        {
            this.StarStopReloj(Relojes.Reloj.Primero);
        }

        private void btnIniciar2_Click(object sender, EventArgs e)
        {
            this.StarStopReloj(Relojes.Reloj.Segundo);
        }

        private void btnIniciar3_Click(object sender, EventArgs e)
        {
            this.StarStopReloj(Relojes.Reloj.Tercero);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.ireloj.KillEmAll();
        }
    }
}
