﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Contador
    {
        public delegate void EventoReloj(Relojes.Reloj r, string tiempo);
        public event EventoReloj EventoTiempo;

        private DateTime inicio;
        private Relojes.Reloj reloj;
        private Thread timer;

        public Thread Hilo
        {
            get
            {
                return this.timer;
            }
        }

        public Contador(Relojes.Reloj r, IEvento imprimir)
        {
            this.reloj = r;
            this.timer = new Thread(EjecutarTimer);
            this.timer.Start();
            this.EventoTiempo += imprimir.ImprimirReloj;
            
        }

        public void EjecutarTimer()
        {
            this.inicio = DateTime.Now;
            do
            {
                this.EventoTiempo.Invoke(reloj, this.inicio.TiempoTranscurrido());
                Thread.Sleep(100);
            } while (true);
        }
    }
}
