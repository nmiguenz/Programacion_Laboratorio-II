﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

    public class Relojes : IReloj
    {
        public enum Reloj { Primero, Segundo, Tercero }

        private int cantidad;
        private Dictionary<Reloj, Contador> hilos;
        private IEvento referencia;

        private Relojes()
        {
            this.hilos = new Dictionary<Reloj, Contador>();
        }

        public Relojes(int cantidad, IEvento referencia) : this()
        {
            this.cantidad = cantidad;
            this.referencia = referencia;
        }

        public Relojes CargarReloj(Relojes.Reloj item)
        {
            Relojes auxReloj = this;
            if (hilos.ContainsKey(item))
            {
                foreach (KeyValuePair<Reloj, Contador> auxItem in this.hilos)
                {
                    if(auxItem.Key == item)
                    {
                        if (hilos[item].Hilo.IsAlive)
                            hilos[item].Hilo.Abort();
                        else
                        {
                            auxReloj -= item;
                            auxReloj += item;
                        }
                    }
                }
            }
            else
            {
                if (this.cantidad < 3)
                {
                    auxReloj += item;
                }
                else
                {
                    throw new SinEspacioException("El cupo de relojes esta completo");
                }
            }
            return auxReloj;
        }

        public void KillEmAll()
        {
            string ubicacion = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            //Recibe como parametro el archivo a escribir
            StreamWriter sw = new StreamWriter(ubicacion +"hilos.txt");
            try
            {
                foreach (KeyValuePair<Reloj, Contador> item in this.hilos)
                {
                    if (item.Value.Hilo.IsAlive)
                    {
                        item.Value.Hilo.Abort();
                        sw.WriteLine(item.Value.ToString());
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("No se pudo guardar el archivo .txt", e);
            }
            finally
            {
                sw.Close();
            }
        }

        
        public static Relojes operator +(Relojes r, Reloj item)
        {

            Contador valor = new Contador(item, r.referencia);
            r.hilos.Add(item, valor);

            return r;
        }

        public static Relojes operator -(Relojes r, Reloj item)
        {
            r.hilos.Remove(item);
            return r;
        }

    }
}
