﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;


namespace TestReloj
{
    [TestClass]
    public class UnitTest1 : IEvento
    {
        public void ImprimirReloj(Relojes.Reloj reloj, string dato)
        {
            throw new NotImplementedException();
        }

        //Agregar un test unitario que pruebe su excepción SinEspacioException.
        [TestMethod]
        [ExpectedException(typeof(SinEspacioException))]
        public void TestMethod2()
        {
            //Arrange
            Relojes relojes1 = new Relojes(2, this);

            try
            {
                //Act
                relojes1 += Relojes.Reloj.Primero;
                relojes1 += Relojes.Reloj.Segundo;
                relojes1 += Relojes.Reloj.Tercero;
                relojes1 += Relojes.Reloj.Tercero;
            }
            catch (Exception e)
            {

                throw new SinEspacioException(e.Message);
            }

        }
    }
}
