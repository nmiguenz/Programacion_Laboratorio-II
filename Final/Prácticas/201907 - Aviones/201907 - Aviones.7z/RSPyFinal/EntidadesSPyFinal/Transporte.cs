﻿namespace EntidadesSPyFinal
{
    public abstract class Transporte
    {
        protected int velocidad;


        public abstract string Transportar();
    }
}
