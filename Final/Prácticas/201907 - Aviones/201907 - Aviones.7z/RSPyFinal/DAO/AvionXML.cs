﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using SPyFinal;

namespace Datos
{
    public class AvionXML 
    {
        private static readonly string rutaArchivo;

        /// <summary>
        /// Asigna un valor al connectionString
        /// </summary>
        static AvionXML()
        {
            rutaArchivo = "";
        }

    }
}
