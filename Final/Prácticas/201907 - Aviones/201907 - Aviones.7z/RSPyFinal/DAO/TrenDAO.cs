﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using SPyFinal;

namespace Datos
{
    public class TrenDAO 
    {

        static string connectionString;
       
        /// <summary>
        /// Asigna un valor al connectionString
        /// </summary>
        static TrenDAO()
        {
            connectionString = "...";
        }

        
    }
}
