﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using PP;

namespace FinalLaboII
{
    public partial class RSPyFinalForm : Form
    {
        public List<Transporte> listaTransportes;
        public List<Thread> hilos;
        public RSPyFinalForm()
        {
            InitializeComponent();
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {

        }

        private void BtnViajar_Click(object sender, EventArgs e)
        {

        }

        private void BtnMostrarTrenes_Click(object sender, EventArgs e)
        {

        }

        private void ComenzarViaje(Transporte transporte)
        {

        }

        private void BtnMostrarAvion_Click(object sender, EventArgs e)
        {

        }

        private void BtnAgregarTren_Click(object sender, EventArgs e)
        {

        }
    }
}
